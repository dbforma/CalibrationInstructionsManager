﻿namespace CalibrationInstructionsManager.Core.Models.Types
{
    public interface IChannelSettingType
    {
        int Id { get; set; }
        string Name { get; set; }
    }
}