﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using CalibrationInstructionsManager.Core.Models.Parameters.Contract;

namespace ChannelSettings.Module.Service
{
    public interface IChannelSettingsDetailService
    {
        void PassChannelSettingParametersToDatabase(Dictionary<string, int> dict);
        void GetParameters(ObservableCollection<IChannelSettingParameters> channelSettingParameters);
    }
}