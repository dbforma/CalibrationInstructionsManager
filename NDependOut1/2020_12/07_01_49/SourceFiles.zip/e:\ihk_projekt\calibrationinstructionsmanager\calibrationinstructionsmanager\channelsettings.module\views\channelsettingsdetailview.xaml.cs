﻿using System.Windows.Controls;

namespace ChannelSettings.Module.Views
{
    /// <summary>
    /// Interaction logic for ChannelSettingsDetailView.xaml
    /// </summary>
    public partial class ChannelSettingsDetailView : UserControl
    {
        public ChannelSettingsDetailView()
        {
            InitializeComponent();
        }
    }
}
