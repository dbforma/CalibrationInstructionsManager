﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using CalibrationInstructionsManager.Core;
using CalibrationInstructionsManager.Core.Data;
using CalibrationInstructionsManager.Core.Models.Parameters;
using CalibrationInstructionsManager.Core.Models.Templates;
using Prism.Regions;

namespace DefaultConfigurations.Module.ViewModels
{
    public class DefaultConfigurationsDetailViewModel : ViewModelBase
    {
        #region Properties
        private IDefaultConfigurationTemplate _selectedDefaultConfigurationTemplate;
        public IDefaultConfigurationTemplate SelectedDefaultConfigurationTemplate { get { return _selectedDefaultConfigurationTemplate; } set { SetProperty(ref _selectedDefaultConfigurationTemplate, value); } }

        private ObservableCollection<DefaultConfigurationParameters> _observableSelectedParameters;
        public ObservableCollection<DefaultConfigurationParameters> ObservableSelectedParameters { get { return _observableSelectedParameters; } set { SetProperty(ref _observableSelectedParameters, value); } }

        private ObservableCollection<DefaultConfigurationParameters> _observableParameterCollection;
        public ObservableCollection<DefaultConfigurationParameters> ObservableParameterCollection { get { return _observableParameterCollection; } set { SetProperty(ref _observableParameterCollection, value); } }

        private IPostgresql _database;

        #endregion // Properties

        public DefaultConfigurationsDetailViewModel(IPostgresql database, IRegionManager regionManager)
         {
            _database = database;
            ObservableParameterCollection = new ObservableCollection<DefaultConfigurationParameters>();
            ObservableSelectedParameters = new ObservableCollection<DefaultConfigurationParameters>();
            GetValuesAndTypesFromDatabase();
         }

        #region Methods

        public ObservableCollection<DefaultConfigurationParameters> GetValuesAndTypesFromDatabase()
        {
            ObservableParameterCollection.Clear();

            foreach (var item in _database.GetDefaultConfigurationValueTypeParameters().ToList())
            {
                ObservableParameterCollection.Add(item);
            }
            return ObservableParameterCollection;
        }

        public override void OnNavigatedTo(NavigationContext navigationContext)
        {
            if (navigationContext.Parameters.ContainsKey("selectedTemplate"))
            {
                //TODO: Handle InvalidCastException in a more proper manner
                try
                {
                    SelectedDefaultConfigurationTemplate = (IDefaultConfigurationTemplate)navigationContext.Parameters.GetValue<Object>("selectedTemplate");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    return;
                }
                
            
                ObservableSelectedParameters.Clear();
            
                for (int i = 0; i < ObservableParameterCollection.Count; i++)
                {
                    if (SelectedDefaultConfigurationTemplate.Id == ObservableParameterCollection[i].ParameterId)
                    {
                        ObservableSelectedParameters.Add(ObservableParameterCollection[i]);
                    }
                }
            
            }
            
            var defaultConfiguration = navigationContext.Parameters["selectedTemplate"] as IDefaultConfigurationTemplate;
            
            if (defaultConfiguration != null)
            {
                SelectedDefaultConfigurationTemplate = defaultConfiguration;
            }
        }

        public override bool IsNavigationTarget(NavigationContext navigationContext)
        {
            var defaultConfiguration = navigationContext.Parameters["selectedTemplate"] as IDefaultConfigurationTemplate;
        
            if (defaultConfiguration != null)
            {
                // Create new instance if Id does not match and parameter is not null
                return SelectedDefaultConfigurationTemplate != null && SelectedDefaultConfigurationTemplate.Id == defaultConfiguration.Id;
            }

            return true;
            
        }
        
        public void OnNavigatedFrom(NavigationContext navigationContext)
        {
            base.OnNavigatedFrom(navigationContext);
            }

        #endregion // Methods
    }
}

