﻿using Prism.Events;

namespace CalibrationInstructionsManager.Core.Events
{
    public class MessageSentEvent : PubSubEvent<string>
    {
    }
}
