﻿using System.Windows.Controls;

namespace ChannelSettings.Module.Views
{
    /// <summary>
    /// Interaction logic for ChannelSettingsOverviewView.xaml
    /// </summary>
    public partial class ChannelSettingsOverviewView : UserControl
    {
        public ChannelSettingsOverviewView()
        {
            InitializeComponent();
        }
    }
}
